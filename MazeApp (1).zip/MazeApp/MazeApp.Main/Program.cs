﻿using MazeApp.Infrastructure;
using MazeApp.Services;
using System;

namespace MazeApp.Main
{
    class Program
    {
        static void Main(string[] args)
        {
            // initialise Passage
            var passage = new Passage(new ChartLocations());
            
            // draw chart map
            passage.DrawChart();

            // initialise router
            var router = new Router(passage, new PassageMap());
            // set start locations
            Console.SetCursorPosition(router.CurrentLocation.LocationX, router.CurrentLocation.LocationY);

            // default movement
            var movement = Movement.Up;

            while (!router.Ended)
            {
                var consoleKey = Console.ReadKey().Key;

                switch (consoleKey)
                {
                    case ConsoleKey.DownArrow:
                        movement = Movement.Down;
                        break;
                    case ConsoleKey.UpArrow:
                        movement = Movement.Up;
                        break;
                    case ConsoleKey.LeftArrow:
                        movement = Movement.Left;
                        break;
                    case ConsoleKey.RightArrow:
                        movement = Movement.Right;
                        break;
                }
                router.FollowDirections(movement);
            }

            router.DisplayRouteAudit();

            Console.WriteLine("To Display Route Audit please press any key...");

            Console.ReadLine();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;

            router = new Router(passage, new PassageMap());
            // draw chart again
            passage.DrawChart();
            // initalise location
            Console.SetCursorPosition(router.CurrentLocation.LocationX, router.CurrentLocation.LocationY);
            // process router
            router.ProcessRouter();

            Console.WriteLine("Thanks for running this app.!!Press any key to exit...");
            Console.ReadLine();
            return;
        }
    }
}
