﻿namespace MazeApp.Entity
{
    public class Chart
    {
        public int RowCount { get; set; }
        public int ColCount { get; set; }
        public char[,] ChartArray { get; set; }
        public string DrawChart { get; set; }
    }
}