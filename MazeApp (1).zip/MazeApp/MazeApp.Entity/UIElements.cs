﻿namespace MazeApp.Entity
{
    public class UiElements
    {
        public const string Begin = "S";
        public const string End = "F";
        public const string Wall = "X";
        public const string Route = "<";
    }
}  