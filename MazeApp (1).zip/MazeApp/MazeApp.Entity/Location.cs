﻿using System.Collections.Generic;

namespace MazeApp.Entity
{
    public class Location
    {
        public int LocationX;
        public int LocationY;
        public IList<Location> LocationHistory;
        public bool IsDirty { get; set; }
    }
}