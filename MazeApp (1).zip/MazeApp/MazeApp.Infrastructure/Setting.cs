﻿namespace MazeApp.Infrastructure
{
    public class Setting
    {
        public const string SettingFile = "Setting/MazeMap.txt";
    }
}
