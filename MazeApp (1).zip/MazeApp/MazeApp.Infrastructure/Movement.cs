﻿namespace MazeApp.Infrastructure
{
    public enum Movement
    {
        Right = 1,
        Left = 2,
        Up = 3,
        Down = 4,
    }
}