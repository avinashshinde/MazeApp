﻿using MazeApp.Entity;

namespace MazeApp.Contracts
{
    public interface IChartLocations
    {
        Chart GetChartLocation();
    }
}
