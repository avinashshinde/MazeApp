﻿namespace MazeApp.Contracts
{
    public interface IPassageMap
    {
        void SetLocation(int x , int y);
    }
}