using MazeApp.Infrastructure;

namespace MazeApp.Contracts
{
    public interface IRouter
    {
        void ProcessRouter();
        bool IsMazeRouted(int locationX, int locationY, bool[,] isDirty);
        void FollowDirections(Movement movement);
        void FollowRoute(int x, int y);
        void DisplayRouteAudit();
    }
}