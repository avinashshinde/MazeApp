﻿using MazeApp.Entity;

namespace MazeApp.Contracts
{
    public interface IPassage
    {
        void DrawChart();
        Location GetStartLocation(string uiElement);
        bool IsPassageInRange(int positionX, int locationY);
        bool IsWallOnWay(int positionX, int positionY);
        bool IsEndOfPassage(int positionX, int positionY);
        int ColumnCount { get; }
        int RowCount { get; }
    }
}