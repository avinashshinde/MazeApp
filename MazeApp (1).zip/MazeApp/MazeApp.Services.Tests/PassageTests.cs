﻿using System;
using MazeApp.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MazeApp.Contracts;
using Rhino.Mocks;

namespace MazeApp.Services.Tests
{
    [TestClass]
    public class PassageTests
    {
        private IChartLocations _iChartLocations;
        private Passage _passage;

        [TestInitialize]
        public void TestInitialize()
        {
            // mock objects
            _iChartLocations = MockRepository.Mock<IChartLocations>();
            var chart = new Chart()
                      {
                          ColCount = 4,
                          RowCount = 8,
                          DrawChart = "",
                          ChartArray = new char[8, 4]{{'X', 'X','X','X' },
                                                          { 'S', ' ','X','X' } ,
                                                          { 'X', ' ','X','X' },
                                                          { 'X', ' ',' ','X' },
                                                          { 'X', 'X',' ','X' },
                                                          { 'X', ' ',' ','X' },
                                                          { 'X', ' ','X','X' },
                                                          { 'X', 'F','X','X' }}


                      };

            _iChartLocations.Stub(x => x.GetChartLocation()).Return(chart);
            _passage = new Passage(_iChartLocations);
        }

        [TestMethod]
        public void Check_range_returns_true()
        {
            //Act
            var result = _passage.IsPassageInRange(0, 0);

            //Assert            
            Assert.IsTrue(result, "Within range.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Check_exception_when_out_of_range()
        {
            //Act
            var result = _passage.IsPassageInRange(20, 30);
        }

        [TestMethod]
        public void Check_location_return_true_when_within_the_wall()
        {
            //Act
            var result = _passage.IsWallOnWay(0, 0);

            //Assert            
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Check_start_location_returns_valid_location()
        {
            //Act
            var result = _passage.GetStartLocation(UiElements.Begin);

            //Assert            
            Assert.IsTrue(result.LocationX == 1);
            Assert.IsTrue(result.LocationY == 0);
        }
    }
}
