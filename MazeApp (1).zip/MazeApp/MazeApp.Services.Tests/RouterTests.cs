﻿using MazeApp.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MazeApp.Contracts;
using Rhino.Mocks;
using MazeApp.Infrastructure;

namespace MazeApp.Services.Tests
{
    [TestClass]
    public class RouterTests
    {
        private Router _router;
        private Location _location;
        private IPassageMap _iPassageMap;
        private IPassage _iPassage;

        [TestInitialize]
        public void TestInitialize()
        {
            _iPassageMap = MockRepository.Mock<IPassageMap>();
            _iPassage = MockRepository.Mock<IPassage>();
            _location = new Location() {LocationX = 1, LocationY = 0};

            _iPassage.Stub(x => x.GetStartLocation(UiElements.Begin)).Return(_location);
            _iPassage.Stub(y => y.IsPassageInRange(Arg<short>.Is.Anything, Arg<short>.Is.Anything)).Return(true);
            _iPassage.Stub(z => z.IsEndOfPassage(2, 1)).Return(true);
            _iPassage.Stub(m => m.IsWallOnWay(0, 0)).Return(false);

            _router = new Router(_iPassage, _iPassageMap);
        }

        [TestMethod]
        public void Check_router_moves_right()
        {
            //Act
            _router.FollowDirections(Movement.Right);

            //Assert            
            Assert.AreEqual(_router.CurrentLocation.LocationX, 2);
            Assert.AreEqual(_router.CurrentLocation.LocationY, 0);
        }

        [TestMethod]
        public void Check_router_moves_left()
        {
            //Act
            _router.FollowDirections(Movement.Left);

            //Assert            
            Assert.AreEqual(_router.CurrentLocation.LocationX, 0);
            Assert.AreEqual(_router.CurrentLocation.LocationY, 0);
        }

        [TestMethod]
        public void Check_router_moves_up()
        {
            //Act
            _router.FollowDirections(Movement.Down);
            _router.FollowDirections(Movement.Up);

            //Assert            
            Assert.AreEqual(_router.CurrentLocation.LocationX, 1);
            Assert.AreEqual(_router.CurrentLocation.LocationY, 0);

        }

        [TestMethod]
        public void Check_router_moves_down()
        {
            //Act
            _router.FollowDirections(Movement.Down);

            //Assert            
            Assert.AreEqual(_router.CurrentLocation.LocationX, 1);
            Assert.AreEqual(_router.CurrentLocation.LocationY, 1);
        }
    }
}
