﻿using MazeApp.Contracts;
using MazeApp.Entity;
using MazeApp.Infrastructure;
using System.IO;

namespace MazeApp.Services
{
    public class ChartLocations : IChartLocations
    {
        public Chart GetChartLocation()
        {
            var chart = new Chart();
            var allLines = File.ReadAllLines(Setting.SettingFile);
            chart.DrawChart = File.ReadAllText(Setting.SettingFile);

            chart.RowCount = allLines.Length;
            chart.ColCount = allLines[0].Length;

            chart.ChartArray = new char[chart.RowCount, chart.ColCount];

            for (var i = 0; i < chart.ChartArray.GetLength(0); i++)
            {
                for (var j = 0; j < chart.ChartArray.GetLength(1); j++)
                {
                    chart.ChartArray[i, j] = allLines[i][j];
                }
            }
            return chart;
        }
    }
}