﻿using MazeApp.Contracts;
using System;

namespace MazeApp.Services
{
    public class PassageMap : IPassageMap
    {
        public void SetLocation(int x , int y)
        {
            Console.SetCursorPosition(x,y);
        }
    }
}