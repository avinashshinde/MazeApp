﻿using MazeApp.Contracts;
using MazeApp.Entity;
using System;

namespace MazeApp.Services
{
    public class Passage : IPassage
    {
        private readonly Chart _chart;
        public Passage(IChartLocations chartLocations)
        {
            _chart = chartLocations.GetChartLocation();
        }

        public void DrawChart()
        {
            Console.WriteLine(_chart.DrawChart);
        }

        public Location GetStartLocation(string uiElement)
        {
            for (var i = 0; i < _chart.ChartArray.GetLength(0); i++)
            {
                for (var j = 0; j < _chart.ChartArray.GetLength(1); j++)
                {
                    if (_chart.ChartArray[i, j].ToString().Equals(uiElement))
                        return new Location() {LocationX = i, LocationY = j};
                }
            }

            return new Location() {LocationX = -1, LocationY = -1};
        }

        public bool IsPassageInRange(int locationX, int locationY)
        {
            if (locationX < 0 || locationX > _chart.ChartArray.GetLength(0))
                throw new ArgumentOutOfRangeException(nameof(locationX));
            if (locationY < 0 || locationY > _chart.ChartArray.GetLength(1))
                throw new ArgumentOutOfRangeException(nameof(locationY));

            return true;
        }

        public bool IsWallOnWay(int positionX, int positionY)
        {
            var element = _chart.ChartArray[positionY, positionX].ToString();
            return element.Equals(UiElements.Wall);
        }

        public bool IsEndOfPassage(int positionX, int positionY)
        {
            var element = _chart.ChartArray[positionY, positionX].ToString();
            return element.Equals(UiElements.End);
        }

        public int ColumnCount => _chart.ColCount;

        public int RowCount => _chart.RowCount;
    }
}
