﻿using MazeApp.Contracts;
using MazeApp.Entity;
using MazeApp.Infrastructure;
using System;
using System.Collections.Generic;
using System.Threading;

namespace MazeApp.Services
{
    // Main router class to hold all router logic
    public class Router : IRouter
    {
        private readonly IPassage _passage;
        private readonly IPassageMap _console;
        public Location CurrentLocation;
        public  bool Ended;

        public Router(IPassage passage, IPassageMap console)
        {
            _passage = passage;
            _console = console;
            CurrentLocation = _passage.GetStartLocation(UiElements.Begin);
            CurrentLocation.LocationHistory = new List<Location>();
        }      
      
        public void FollowDirections(Movement movement)
        {
            switch (movement)
            {
                case Movement.Up:
                    FollowRoute(0, -1);
                    break;

                case Movement.Right:
                    FollowRoute(1, 0);
                    break;

                case Movement.Down:
                    FollowRoute(0, 1);
                    break;

                case Movement.Left:
                    FollowRoute(-1, 0);
                    break;
            }
        }

        public void FollowRoute(int x, int y)
        {
            try
            {
                var positionX = CurrentLocation.LocationX + x;
                var positionY = CurrentLocation.LocationY + y;

                if (!_passage.IsPassageInRange(positionX, positionY)) return;

                // check end of passage
                if (_passage.IsEndOfPassage(positionX, positionY))
                {
                    Ended = true;
                }
                if (!_passage.IsWallOnWay(positionX, positionY))
                {
                    CurrentLocation.LocationX = positionX;
                    CurrentLocation.LocationY = positionY;
                    RouterPath(positionX, positionY);
                    // add to audit
                    CurrentLocation.LocationHistory.Add(new Location() { LocationX = positionX, LocationY = positionY });
                }
                else
                {
                    RouterPath(CurrentLocation.LocationX, CurrentLocation.LocationY);
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Out of range exception ..");
            }
        }

        public void ProcessRouter()
        {
            var isDirty = new bool[_passage.RowCount, _passage.ColumnCount];
            IsMazeRouted(CurrentLocation.LocationX, CurrentLocation.LocationY, isDirty);
        }

        public bool IsMazeRouted(int locationX, int locationY, bool[,] isDirty)
        {
            var isPathCorrect = false;
            var continueNext = true;

            if (locationX >= _passage.RowCount || locationX < 0 || locationY >= _passage.ColumnCount || locationY < 0)
                continueNext = false;
            else
            {
                if (_passage.IsEndOfPassage(locationX, locationY))
                {
                    isPathCorrect = true;
                    continueNext = false;
                }

                if (_passage.IsWallOnWay(locationX, locationY))
                    continueNext = false;
                else
                {
                    Thread.Sleep(100);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    _console.SetLocation(locationX, locationY);
                    Console.Write(UiElements.Route);
                    CurrentLocation.LocationHistory.Add(new Location() { LocationX = locationX, LocationY = locationY });
                }

                if (isDirty[locationX, locationY])
                    continueNext = false;

            }

            if (continueNext)
            {
                isDirty[locationX, locationY] = true;
                isPathCorrect = IsMazeRouted(locationX + 1, locationY, isDirty);
                isPathCorrect = isPathCorrect || IsMazeRouted(locationX, locationY + 1, isDirty);
                isPathCorrect = isPathCorrect || IsMazeRouted(locationX - 1, locationY, isDirty);
                isPathCorrect = isPathCorrect || IsMazeRouted(locationX, locationY - 1, isDirty);
            }
            return isPathCorrect;
        }

        public void DisplayRouteAudit()
        {
            foreach (var location in CurrentLocation.LocationHistory)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                _console.SetLocation(location.LocationX, location.LocationY);
                Console.Write(UiElements.Route);
            }
        }

        private void RouterPath(int x, int y )
        {
            _console.SetLocation(x,y);
            Console.Write(UiElements.Begin);
            _console.SetLocation(x,y);
        }
    }
}
